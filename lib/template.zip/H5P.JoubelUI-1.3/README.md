h5p-joubel-ui
=============

This is a utility library for creating UI widgets. It does not implement attach, so it has to be actively used by
other libraries

Version history
===============
Version  | Description
---------| -------------
1.0      | Initial version
1.1      | Added H5P.JoubelUI.createHelpTextDialog(), H5P.JoubelUI.createProgressCircle(), H5P.JoubelUI.createThrobber(), H5P.JoubelUI.createSimpleRoundedButton() and H5P.JoubelUI.createButton()
1.2      | Added H5P.JoubelUI.createScoreBar(), H5P.JoubelUI.createSlider() and H5P.JoubelUI.createProgressbar()

License
=======
(The MIT License)

Copyright (c) 2015 Joubel AS

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
